//
//  Color.swift
//  Tradescape
//
//  Created by Marko Radulovic (RIT Student) on 29.11.2023..
//

import SwiftUI

extension Color{
    public static let mainRed:Color = Color(UIColor(red: 173/255, green: 38/255, blue: 26/255, alpha: 1.0))
    public static let mainBlack:Color = Color(UIColor(red: 3/255, green: 21/255, blue: 22/255, alpha: 1.0))

}
