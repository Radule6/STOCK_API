//
//  AlamofireTutorialView.swift
//  Tradescape
//
//  Created by Marko Radulovic (RIT Student) on 29.11.2023..
//

import SwiftUI
import Alamofire
struct AlamofireTutorialView: View {
    let apiUrl = "https://stock-cx2r.onrender.com/api/getStocks"
    @State var stocks :[Stock] = []
    @State var articles = Articles()
    
    func getStockData(){
        AF.request(apiUrl).responseDecodable(of: [Stock].self) { response in
               switch response.result {
               case .success(let stocks):
                   self.stocks = stocks
               case .failure(let error):
                   print("Error fetching data: \(error)")
               }
           }
        
    }

    
    var body: some View {
        VStack{
            NavigationView {
                       List(stocks, id: \.symbol) { stock in
                               VStack(alignment: .leading) {
                                   HStack{
                                       Text(stock.name)
                                           .font(.headline)
                                       Spacer()
                                       Text(stock.previousClosePrice)
                                   }
                                   Text(stock.symbol)
                                       .font(.subheadline)
                                       .foregroundColor(.gray)
                               }
                           }
                       }
            .onAppear{
                getStockData()
            }
                       .navigationBarTitle("Stocks")
        }
    }
}

#Preview {
    AlamofireTutorialView()
}
