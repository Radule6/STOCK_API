import SwiftUI
import Firebase

class AppSettings: ObservableObject {
    @Published var isDarkMode: Bool

    init() {
        self.isDarkMode = UserDefaults.standard.object(forKey: "isDarkMode") as? Bool ?? false
    }

    func toggleDarkMode() {
        isDarkMode.toggle()
        UserDefaults.standard.set(isDarkMode, forKey: "isDarkMode")
    }
    
    
}

@main
struct TradescapeApp: App {
    @StateObject private var appSettings = AppSettings()

    init() {
        FirebaseApp.configure()
    }

    var body: some Scene {
        WindowGroup {
            RootView()
                .preferredColorScheme(appSettings.isDarkMode ? .dark : .light)
                .environmentObject(appSettings)
        }
    }
}
