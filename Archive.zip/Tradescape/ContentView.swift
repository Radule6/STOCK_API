//
//  ContentView.swift
//  Tradescape
//
//  Created by Marko Radulovic (RIT Student) on 27.11.2023..
//

import SwiftUI

struct ContentView: View {
    @State private var numberString = ""

    var body: some View {
        VStack {
            TextField("Enter a number", text: $numberString)       
                .keyboardType(.numberPad)
                              .padding()
                              .textFieldStyle(.roundedBorder)
        }
//        .preferredColorScheme(isDarkMode == true ? .dark:.light)
    }
}

#Preview {
    ContentView()
}
