//
//  SignEmailModel.swift
//  Tradescape
//
//  Created by Marko Radulovic (RIT Student) on 27.11.2023..
//

import Foundation


class SignEmailModel:ObservableObject{
    
    @Published var email = ""
    @Published var password = ""
    @Published var confirmPass = ""
    
    
    func signUp() async throws ->Bool{
        guard !email.isEmpty, !password.isEmpty else{
            print("No email or password provided")
            return false
        }
        if(validateEmail(email: email)){

            if password == confirmPass{
                _ = try await AuthManager.sharedInstance.signUp(email: email, password: password)
                return true
            }
        }
        return false

    }
    
    
    func signIn() async throws  -> Bool{
        guard !email.isEmpty, !password.isEmpty
        else{
            print("No email or password provided")
            return false
        }
        
        if(validateEmail(email: email)){
            _ = try await AuthManager.sharedInstance.signIn(email: email, password: password)
            return true
        }
            return false
    }
    
    func validateEmail (email:String) -> Bool {
        let emailValidationRegex = "^[\\p{L}0-9!#$%&'*+\\/=?^_`{|}~-][\\p{L}0-9.!#$%&'*+\\/=?^_`{|}~-]{0,63}@[\\p{L}0-9-]+(?:\\.[\\p{L}0-9-]{2,7})*$"
        
        let emailValidationPredicate = NSPredicate(format: "SELF MATCHES %@", emailValidationRegex)
        
        return emailValidationPredicate.evaluate(with: email)
    }
}
