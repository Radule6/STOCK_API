//
//  Stock.swift
//  Tradescape
//
//  Created by Marko Radulovic (RIT Student) on 29.11.2023..
//

import Foundation


struct Stock: Codable {
    let name: String
    let symbol: String
    let about: String
    let founded: String
    let headquarters: String
    let website: String
    let ceo: String
    let previousClosePrice: String
    let preMarketPrice: String
    let dayRange: String
    let yearRange: String
    let marketCap: String
    let avgVolume: String
    let peRatio: String
    let dividendYield: String
    let primaryExchange: String
    let cdpClimateChangeScore: String
    
    init() {
        self.name = ""
        self.symbol = ""
        self.about = ""
        self.founded = ""
        self.headquarters = ""
        self.website = ""
        self.ceo = ""
        self.previousClosePrice = ""
        self.preMarketPrice = ""
        self.dayRange = ""
        self.yearRange = ""
        self.marketCap = ""
        self.avgVolume = ""
        self.peRatio = ""
        self.dividendYield = ""
        self.primaryExchange = ""
        self.cdpClimateChangeScore = ""
    }
    init(name: String, symbol: String, about: String, founded: String, headquarters: String, website: String, ceo: String, previousClosePrice: String, preMarketPrice: String, dayRange: String, yearRange: String, marketCap: String, avgVolume: String, peRatio: String, dividendYield: String, primaryExchange: String, cdpClimateChangeScore: String) {
        self.name = name
        self.symbol = symbol
        self.about = about
        self.founded = founded
        self.headquarters = headquarters
        self.website = website
        self.ceo = ceo
        self.previousClosePrice = previousClosePrice
        self.preMarketPrice = preMarketPrice
        self.dayRange = dayRange
        self.yearRange = yearRange
        self.marketCap = marketCap
        self.avgVolume = avgVolume
        self.peRatio = peRatio
        self.dividendYield = dividendYield
        self.primaryExchange = primaryExchange
        self.cdpClimateChangeScore = cdpClimateChangeScore
    }
}
