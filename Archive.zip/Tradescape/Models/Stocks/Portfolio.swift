//
//  Portfolio.swift
//  Tradescape
//
//  Created by Marko Radulovic (RIT Student) on 02.12.2023..
//

import Foundation


