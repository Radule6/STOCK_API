//
//  Stocks.swift
//  Tradescape
//
//  Created by Marko Radulovic (RIT Student) on 29.11.2023..
//

import Foundation
import Alamofire

@Observable
class Stocks {
    var stocks :[Stock] = []
    let apiURL = "http://localhost:3000/api/getStocks"
    
    init(){
        getData()
        Timer.scheduledTimer(withTimeInterval: 30 * 60, repeats: true) { _ in
                self.getData()
            print("Stock Updated")
            }
    }
    func getData(){
        AF.request(apiURL).responseDecodable(of: [Stock].self) { response in
               switch response.result {
               case .success(let stocks):
                   self.stocks = stocks
               case .failure(let error):
                   print("Error fetching data: \(error)")
               }
           }
    }
}



