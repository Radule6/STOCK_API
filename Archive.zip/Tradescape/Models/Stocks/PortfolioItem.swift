//
//  PortfolioItem.swift
//  Tradescape
//
//  Created by Marko Radulovic (RIT Student) on 02.12.2023..
//

import Foundation

struct PortoflioItem:Codable, Identifiable{

    
    var id = UUID()
    var stock:Stock
    var amount: Int
    var totalPrice:Double
    var stockPriceDuring:Double
    var creationDate = Date()

}
