//
//  Articles.swift
//  Tradescape
//
//  Created by Marko Radulovic (RIT Student) on 30.11.2023..
//

import Foundation
import Alamofire

@Observable
class Articles {
    var list :[FeedItem] = []

    
    init(){
        let url = "https://www.alphavantage.co/query?function=NEWS_SENTIMENT&tickers=AAPL&apikey=demo"

        AF.request(url).responseDecodable(of: FeedResponse.self) { response in
            switch response.result {
            case .success(let feedResponse):
                self.list = feedResponse.feed
            case .failure(let error):
                print(error)
            }
        }
    
    }
}

