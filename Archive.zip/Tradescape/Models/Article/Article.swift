//
//  Article.swift
//  Tradescape
//
//  Created by Marko Radulovic (RIT Student) on 30.11.2023..
//

import SwiftUI

struct FeedItem: Codable {
    var title: String
    var summary: String
    var authors:[String]
    var time_published:String
    var category_within_source:String
    var source:String
    var url:String


}



struct FeedResponse: Codable {
    var feed: [FeedItem]
}
