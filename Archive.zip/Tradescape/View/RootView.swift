//
//  RootView.swift
//  Tradescape
//
//  Created by Marko Radulovic (RIT Student) on 27.11.2023..
//

import SwiftUI

struct RootView: View {
    @State var showSignedIn:Bool = true
    @State private var selectedTab = Tabs.dashboard
    @State private var balance:Double = 0.00
  
    
    var body: some View {
        TabView(selection:$selectedTab){
            
            DashboardView(balance:$balance)
                .toolbarBackground(Color("backgroundColor"), for: .tabBar)
            
                .tabItem {
                    Image(systemName: "house")
                }
                .tag(Tabs.dashboard)
            NavigationView{
                StoreView(balance:$balance)
            }
                .toolbarBackground(Color("backgroundColor"), for: .tabBar)
            
                .tabItem {
                    Image(systemName: "bag.fill")
                }
                .tag(Tabs.stocks)
                NewsView()
                .toolbarBackground(Color("backgroundColor"), for: .tabBar)
                .tabItem {
                    Image(systemName: "newspaper")
                }
                .tint(.black)
                .tag(Tabs.news)
            NavigationView{
                SettingsView(showSignedIn: $showSignedIn)
            }
                .toolbarBackground(Color("backgroundColor"), for: .tabBar)
                .tabItem {
                    Image(systemName: "gear")
                }
                .tag(Tabs.settings)
        }.accentColor(Color("mainAppColor"))
        
    
            .onAppear{
                let authUser = try? AuthManager.sharedInstance.getAuthUser()
                self.showSignedIn = authUser == nil
            }
                .fullScreenCover(isPresented: $showSignedIn, content: {
                    NavigationStack{
                        SignInView(showSignedIn: $showSignedIn)
                    }
                })
    }
}

#Preview {
    RootView()
}


enum Tabs:Hashable{
    case dashboard
    case stocks
    case news
    case settings
}
