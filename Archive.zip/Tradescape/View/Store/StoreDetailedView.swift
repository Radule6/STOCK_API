//
//  StoreDetailedView.swift
//  Tradescape
//
//  Created by Marko Radulovic (RIT Student) on 01.12.2023..
//

import SwiftUI

struct StoreDetailedView: View {
    let stock: Stock
    @Binding var balance:Double
    @State var isShown:Bool = false
    @State var showAlert:Bool = false
    @State var quantity:Int = 0
    @State private var transactionItems: [TransactionItem] = []
    @State private var portfolioItems: [PortoflioItem] = []
    
    
    
    func loadData(){
        if let encodedData1 = UserDefaults.standard.data(forKey: "transactionItems") {
            // Decoding the data into an array of CustomObject
            let decoder = PropertyListDecoder()
            do {
                let decodedObjects = try decoder.decode([TransactionItem].self, from: encodedData1)
                // Use the decoded array
                self.transactionItems = decodedObjects
            } catch {
                // Handle decoding error
                print("Error decoding custom objects: \(error)")
            }
        } else {
            // Handle missing data in UserDefaults
            print("No data found in UserDefaults")
            return
        }
        if let encodedData1 = UserDefaults.standard.data(forKey: "portfolioItems") {
            // Decoding the data into an array of CustomObject
            let decoder = PropertyListDecoder()
            do {
                let decodedObjects = try decoder.decode([PortoflioItem].self, from: encodedData1)
                // Use the decoded array
                self.portfolioItems = decodedObjects
            } catch {
                // Handle decoding error
                print("Error decoding custom objects: \(error)")
            }
        } else {
          return
        }
        
        
        
    }
    
    
    
    
    var formattedBalance: String {
        return String(format: "$%.2f", balance)
    }
    var formattedTotalAmount: String {
        return String(format: "%.2f", totalAmount)
    }
    var price:Double {
        return Double(stock.preMarketPrice.replacingOccurrences(of: "$", with: ""))!
    }
    
    var totalAmount :Double{
        return (Double(quantity)*price)
    }
    var totalQuantity:Int{
        return Int(floor(balance / price))
    }
    
    var body: some View {
        VStack {
            Form{
                Section(header:Text("Current Prices")){
                    VStack(alignment: .leading) {
                        Text("Primary Exchange: \(stock.primaryExchange)")
                        Divider()
                        Text("Previous Close Price: \(stock.previousClosePrice)")
                        Divider()
                        Text("Current Price: \(stock.preMarketPrice)")
                        Divider()
                        Text("Day Range: \(stock.dayRange)")
                        Divider()
                        Text("Year Range: \(stock.yearRange)")
                        Divider()
                        Text("Market Cap: \(stock.marketCap)")
                        Divider()
                        Text("Average Volume: \(stock.avgVolume)")
                        Divider()
                        Text("P/E Ratio: \(stock.peRatio)")
                        Divider()
                        Text("Dividend Yield: \(stock.dividendYield)")
                        Divider()
                        Text("CDP climate change score: \(stock.cdpClimateChangeScore)")
                        Divider()
                        Button(action: {
                            
                            if balance < price{
                                showAlert = true
                                return
                            }
                            isShown = true
                        }, label: {
                            Text("Buy")
                                .font(.headline)
                                .foregroundColor(.white)
                                .frame(maxWidth: 100)
                                .frame(height: 40)
                                .background(Color("mainAppColor"))
                                .cornerRadius(10)
                        })
                    }
                }
                
                Section(header:Text("About the company")){
                    VStack(alignment: .leading) {
                        Text("Name: \(stock.name)")
                        Divider()
                        Text("Symbol: \(stock.symbol)")
                        Divider()
                        Text("Founded: \(stock.founded)")
                        Divider()
                        Text("Headquarters: \(stock.headquarters)")
                        Divider()
                        Text("CEO: \(stock.ceo)")
                        Divider()
                        Text("Website: \(stock.website)")
                        Divider()
                        Text("About:")
                        Text(stock.about)
                    }
                }
                
            }
            .background(Color("backgroundColor"))
            .scrollContentBackground(.hidden)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar{
                ToolbarItem(placement:.principal){
                    HStack{
                        Image(stock.symbol.lowercased())
                            .resizable()
                            .scaledToFit()
                            .frame(width: 30, height: 30)
                            .shadow(color: Color.white.opacity(0.2), radius: 10, x: 0, y: 1)
                        Text(stock.name)
                    }
                }
            }
        }.background(Color("backgroundColor"))
            .sheet(isPresented: $isShown){
                VStack{
                    HStack {
                        Text("Buy \(stock.name)")
                            .font(.title)
                            .fontWeight(.bold)
                            .foregroundColor(Color("mainAppColor"))
                        Image(stock.symbol.lowercased())
                            .resizable()
                            .scaledToFit()
                            .frame(width: 30, height: 30)
                            .shadow(color: Color.white.opacity(0.2), radius: 10, x: 0, y: 1)
                        
                        Spacer()
                    }.padding()
                    HStack {
                        Text("Do you want to buy \(stock.symbol) \nCurrent price : \(stock.preMarketPrice)")
                            .font(.headline)
                            .fontWeight(.bold)
                            .foregroundColor(.primary)
                        Spacer()
                    }.padding()
                    VStack {
                        HStack{
                            Text("Current Balance: \(formattedBalance)")
                                .fontWeight(.bold)
                            Spacer()
                        }.padding()
                        HStack{
                            
                            Stepper(value: $quantity, in: 0...totalQuantity, label: {
                                Text("Quantity: \(quantity)")
                                    .font(.headline)
                                    .foregroundColor(.primary)
                            })
                            .padding()
                        }
                        HStack{
                            Text("Total Amount: $\(formattedTotalAmount)")
                                .fontWeight(.bold)
                            Spacer()
                        }.padding()
                    }
                    HStack {
                        Button(action: {
                            isShown = false
                        }, label: {
                            Text("Cancel")
                                .font(.headline)
                                .foregroundColor(.red)
                                .frame(maxWidth:200)
                                .frame(height: 55)
                                .background(Color.gray.opacity(0.1))
                                .cornerRadius(10)
                        })
                        
                        
                        Button(action: {
                            let  totalPrice = totalAmount
                            if totalPrice <= 0{
                                showAlert = true
                                return
                            }
                            let transactionItem = TransactionItem(stock: stock, amount: quantity, totalPrice: totalAmount, stockPriceDuring: price)
                            transactionItems.append(transactionItem)
                            let portfolioItem = PortoflioItem(stock: stock, amount: quantity, totalPrice: totalAmount, stockPriceDuring: price)
                            let encoder = PropertyListEncoder()
                            if let encodedTransaction = try? encoder.encode(transactionItems) {
                                UserDefaults.standard.set(encodedTransaction, forKey: "transactionItems")
                            } else {
                                print("Error encoding transaction objects")
                            }
                            
                            if(!portfolioItems.isEmpty){
                                var foundMatchingSymbol = false
                                
                                for index in 0..<portfolioItems.count{
                                    if portfolioItems[index].stock.symbol == portfolioItem.stock.symbol{
                                        
                                        portfolioItems[index].amount += portfolioItem.amount
                                        portfolioItems[index].totalPrice += portfolioItem.totalPrice
                                        portfolioItems[index].stockPriceDuring += portfolioItem.stockPriceDuring
                                        foundMatchingSymbol = true
                                        break
                                    }
                                }
                                if !foundMatchingSymbol{
                                    portfolioItems.append(portfolioItem)
                                }
                                if let encodedTransaction = try? encoder.encode(portfolioItems) {
                                    UserDefaults.standard.set(encodedTransaction, forKey: "portfolioItems")
                                } else {
                                    print("Error encoding transaction objects")
                                }
                            }
                            else{
                                portfolioItems.append(portfolioItem)
                                if let encodedTransaction = try? encoder.encode(portfolioItems) {
                                    UserDefaults.standard.set(encodedTransaction, forKey: "portfolioItems")
                                } else {
                                    print("Error encoding transaction objects")
                                }
                            }
                            isShown = false
                            balance -= totalAmount
                            UserDefaults.standard.set(balance, forKey: "balance")
                            
                        }, label: {
                            Text("Add to Portfolio")
                                .font(.headline)
                                .foregroundColor(.white)
                                .frame(maxWidth:200)
                                .frame(height: 55)
                                .background(Color("mainAppColor"))
                                .cornerRadius(10)
                        }).alert(isPresented: $showAlert) {
                            Alert(
                                title: Text("Transaction failed"),
                                message: Text("Balance can't be left empty"),
                                dismissButton: .default(Text("Try Again"))
                            )
                        }
                        Spacer()
                    }.padding()
                    Spacer()
                }        }
            .alert(isPresented: $showAlert){
                Alert(title: Text("Insufficient Funds"),
                      message:Text("You need to deposit money to your wallet"),
                      dismissButton: .default(Text("Try Again"))
                )
            }
            .onAppear{
                loadData()
            }
    }
    
}



struct StoreDetailed_Previews: PreviewProvider {
    static var previews: some View {
        let balanceTest: Double = 300
        let appleStock = Stock(
            name: "Apple Inc.",
            symbol: "AAPL",
            about: "Technology company...",
            founded: "April 1, 1976",
            headquarters: "Cupertino, California",
            website: "https://www.apple.com",
            ceo: "Tim Cook",
            previousClosePrice: "$150.00",
            preMarketPrice: "$151.00",
            dayRange: "$149.50 - $152.00",
            yearRange: "$120.00 - $160.00",
            marketCap: "2.5T",
            avgVolume: "50M",
            peRatio: "30.0",
            dividendYield: "1.5%",
            primaryExchange: "NASDAQ",
            cdpClimateChangeScore: "A"
        )
        
        NavigationView {
            StoreDetailedView(stock:appleStock,balance: .constant(balanceTest))
                .preferredColorScheme(.dark)
        }
        .accentColor(Color("mainAppColor"))
    }
}
