//
//  StoreView.swift
//  Tradescape
//
//  Created by Marko Radulovic (RIT Student) on 30.11.2023..
//

import SwiftUI

struct StoreView: View {
    @State var stocks = Stocks()
    @Binding var balance:Double
    var body: some View {
        if stocks.stocks.isEmpty{
            ProgressView()
        }
        else{
            List(stocks.stocks, id: \.symbol) { stock in
                NavigationLink(destination: StoreDetailedView(stock: stock,balance:$balance)) {
                    StoreRow(stock: stock)
                }
                .listRowBackground(Color("backgroundColor"))
            }
            .listStyle(.plain)
            .background(Color("backgroundColor"))
        }
    }
}

struct StoreView_Previews: PreviewProvider {
    static var previews: some View {
        let balanceTest: Double = 20

        NavigationView {
            StoreView(balance: .constant(balanceTest))
                .preferredColorScheme(.dark)
        }
        .accentColor(Color("mainAppColor"))
    }
}


