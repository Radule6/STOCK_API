//
//  StoreDetailedView.swift
//  Tradescape
//
//  Created by Marko Radulovic (RIT Student) on 01.12.2023..
//

import SwiftUI


struct StoreRow: View {
    var stock:Stock
    var body: some View {
        VStack(alignment: .leading) {
            HStack{
                Text(stock.name)
                    .font(.headline)
                    .foregroundColor(.primary)
                
                Spacer()
                Image(stock.symbol.lowercased())
                    .resizable()
                    .scaledToFit()
                    .frame(width: 30, height: 30)
                    .shadow(color: Color.white.opacity(0.2), radius: 10, x: 0, y: 1)
            }
            HStack {
                Text(stock.symbol)
                    .font(.subheadline)
                    .foregroundColor(.gray)
                Text(stock.preMarketPrice)
                
            }
        }
    }
}
