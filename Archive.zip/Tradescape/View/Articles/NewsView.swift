//
//  NewsView.swift
//  Tradescape
//
//  Created by Marko Radulovic (RIT Student) on 30.11.2023..
//

import SwiftUI

struct NewsView: View {
    @State private var articles:Articles = Articles()
    
    var body: some View {
        if articles.list.isEmpty{
            ProgressView()
        }else{
            List(articles.list, id: \.title) { feedItem in
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Image("newsPhoto")
                            .resizable()
                            .scaledToFill()
                        .frame(width: 340,height: 200)
                    }
                    .padding()
                    Button(action: {
                        if let url = URL(string: feedItem.url){
                            UIApplication.shared.open(url, options: [:], completionHandler: nil)
                        }
                    }, label: {
                        Text(feedItem.title)
                            .font(.headline)
                            .foregroundColor(Color("mainAppColor"))
                            .padding(.horizontal)
                    })
                    
                    Text(feedItem.summary)
                        .font(.subheadline)
                        .foregroundColor(.gray)
                        .padding(.horizontal)
                }
                .listRowBackground(Color("backgroundColor"))
                
            }
            .listStyle(.plain)
            .background(Color("backgroundColor"))
            
        }
    }
}

#Preview {
    NewsView()
}
