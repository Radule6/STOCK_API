//
//  SettingsView.swift
//  Tradescape
//
//  Created by Marko Radulovic (RIT Student) on 30.11.2023..
//

import SwiftUI


@MainActor
class Settings:ObservableObject{
    func signOut() throws{
        try AuthManager.sharedInstance.signOut()
    }
}

struct SettingsView: View {
    @EnvironmentObject var appSettings: AppSettings
    @StateObject private var viewModel = Settings()
    @Binding var showSignedIn:Bool
    var body: some View {
        
        Form{
            Section{
                Button(action: {
                    appSettings.toggleDarkMode()
                }, label: {
                    HStack{
                        Text("Change theme")
                            .font(.subheadline)
                            .foregroundColor(.primary)

                        Spacer()
                        Image(systemName: appSettings.isDarkMode ? "moon.fill":"sun.min.fill" )
                            .resizable()
                            .frame(width: 20,height: 20)
                            .foregroundColor(Color("mainAppColor"))

                    }
                })

            }
            Section{
                Button(action: {
                    Task{
                        do{
                            try viewModel.signOut()
                            showSignedIn = true
                        }catch {
                            print("Having issues with logging out")
                        }
                    }
                }, label: {
                    HStack{
                        Text("Sign Out")
                            .font(.subheadline)
                            .foregroundColor(.primary)
                        Spacer()
                        Image(systemName: "arrowshape.turn.up.backward.fill")
                            .resizable()
                            .frame(width: 20,height: 20)
                            .foregroundColor(Color("mainAppColor"))
                    }
                })
        

            }
        }.navigationTitle("Settings")
            .background(Color("backgroundColor"))
            .scrollContentBackground(.hidden)
    }
}


