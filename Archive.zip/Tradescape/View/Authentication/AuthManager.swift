//
//  AuthManager.swift
//  Tradescape
//
//  Created by Marko Radulovic (RIT Student) on 27.11.2023..
//

import Foundation
import FirebaseAuth


struct AuthDataModel {
    let uid:String
    let email:String?
    
    init(user:User){
        self.uid = user.uid
        self.email = user.email
    }
}


class AuthManager {
    
    static let sharedInstance = AuthManager()
    
    private init(){}
    
    
    func signIn(email:String,password:String) async throws -> AuthDataModel {
        let authData = try await Auth.auth().signIn(withEmail: email,password: password)
        return AuthDataModel(user: authData.user)
    }
    
    func signUp(email:String,password:String) async throws -> AuthDataModel {
        let authData = try await Auth.auth().createUser(withEmail: email, password: password)
        return AuthDataModel(user: authData.user)
    }
    
    func signOut() throws{
        try Auth.auth().signOut()
    }
    
    func getAuthUser () throws -> AuthDataModel{
        guard let user = Auth.auth().currentUser else{
            throw URLError(.badServerResponse)
        }
        return AuthDataModel(user: user)
    }
}
