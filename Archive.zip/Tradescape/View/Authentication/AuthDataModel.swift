//
//  AuthDataModel.swift
//  Tradescape
//
//  Created by Marko Radulovic (RIT Student) on 27.11.2023..
//

import Foundation
import FirebaseAuth


struct AuthDataModel {
    let uid:String
    let email:String?
    
    init(user:User){
        self.uid = user.uid
        self.email = user.email
    }
}
