//
//  SignInView.swift
//  Tradescape
//
//  Created by Marko Radulovic (RIT Student) on 27.11.2023..
//

import SwiftUI

struct SignInView: View {
    @State private var viewModel = SignEmailModel()
    @Binding var showSignedIn:Bool
    @State private var showAlert:Bool = false
    
    
    var body: some View {
        VStack{
            Spacer()
            HStack{
                Image("TradeScapesLogo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 300,height: 55)
            }
            .padding(.top)
            Spacer()
            VStack{
                Spacer()
                HStack{
                    Image(systemName: "envelope.fill")
                     .foregroundColor(Color("mainAppColor"))
                    TextField("", text: $viewModel.email,prompt: Text("Email").foregroundColor(Color("mainAppColor")))
                }
                .padding()
                .background(Color.gray.opacity(0.1))
                .cornerRadius(15)
                .foregroundColor(.primary)
                HStack {
                       Image(systemName: "lock.fill")
                        .foregroundColor(Color("mainAppColor"))
                    SecureField("", text: $viewModel.password,prompt:   Text("Password").foregroundColor(Color("mainAppColor")))
                   }
                .padding()
                .background(Color.gray.opacity(0.1))
                .cornerRadius(15)
                .foregroundColor(.primary)
                
                Button(action: {
                    Task{
                        do{
                            let signIn = try await viewModel.signIn()
                            if signIn{
                            showSignedIn = false
                            }else{
                                showAlert = true
                            }

                        }catch{
                            print("error")
                        }
                    }
                }, label: {
                    Text("Sign In")
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 55)
                        .background(Color("mainAppColor"))
                        .cornerRadius(10)
                })
                Spacer()
                HStack{
                    Text("Don't have an account?")
                        .foregroundColor(.primary)
                    NavigationLink{
                        SignUpView(showSignedIn: $showSignedIn)
                    } label: {
                        Text("Sign up")
                            .foregroundColor(Color("mainAppColor"))
                    }
                }
            }
            .padding()
        }//VStack
        .background(Color("backgroundColor"))
        .alert(isPresented: $showAlert){
            Alert(
                title: Text("Incorrect credentials"),
                message: Text("Try again"),
                dismissButton: .default(Text("OK!")))
        }
        .navigationBarBackButtonHidden(true)

    }

}

