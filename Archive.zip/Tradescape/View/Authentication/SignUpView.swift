//
//  SignUpView.swift
//  Tradescape
//
//  Created by Marko Radulovic (RIT Student) on 27.11.2023..
//

import SwiftUI

struct SignUpView: View {
    @State private var viewModel = SignEmailModel()
    @State private var showAlert:Bool = false
    @Binding var showSignedIn:Bool
    var body: some View {
        VStack{
            Spacer()
            HStack{
                Image("TradeScapesLogo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 300,height: 55)
            }//HStack
            .padding(.top)
            Spacer()
            VStack{
                Spacer()
                HStack{
                    Image(systemName: "envelope.fill")
                        .foregroundColor(Color("mainAppColor"))
                    TextField("", text: $viewModel.email,prompt: Text("Email").foregroundColor(Color("mainAppColor")))
                }
                .padding()
                .background(Color.gray.opacity(0.1))
                .cornerRadius(15)
                .foregroundColor(.primary)
                
                HStack {
                    Image(systemName: "lock.fill")
                        .foregroundColor(Color("mainAppColor"))
                    SecureField("", text: $viewModel.password,prompt:   Text("Password").foregroundColor(Color("mainAppColor")))
                }
                .padding()
                .background(Color.gray.opacity(0.1))
                .cornerRadius(15)
                .foregroundColor(.primary)
                HStack {
                    Image(systemName: "lock.fill")
                        .foregroundColor(Color("mainAppColor"))
                    SecureField("", text: $viewModel.confirmPass,prompt:   Text("Confirm Password").foregroundColor(Color("mainAppColor")))
                }
                .padding()
                .background(Color.gray.opacity(0.1))
                .cornerRadius(15)
                .foregroundColor(.primary)
                
                Button(action: {
                    Task{
                        do{
                           let signedUp = try await viewModel.signUp()
                            if signedUp {
                                showSignedIn = false
                            }
                            else{
                                showAlert = true
                            }
                        }catch{
                            print("error")
                        }
                    }
                }, label: {
                    Text("Sign Up")
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 55)
                        .background(Color("mainAppColor"))
                        .cornerRadius(10)
                })
                
                Spacer()
                
                HStack{
                    Text("Already have an account?")
                    NavigationLink{
                        SignInView(showSignedIn: $showSignedIn)
                    } label: {
                        Text("Sign in")
                            .foregroundColor(Color("mainAppColor"))
                    }
                }//HStack
            }//VStack
            .padding()
        }//VStack
        .background(Color("backgroundColor"))
        .alert(isPresented: $showAlert){
            Alert(
                title: Text("Not valid information"),
                message: Text("Try again entering valid information"),
                dismissButton: .default(Text("OK!")))
        }
        .navigationBarBackButtonHidden(true)

    }
}

#Preview {
    SignUpView(showSignedIn: .constant(true))
}
