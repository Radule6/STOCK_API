//
//  DashBoardView.swift
//  Tradescape
//
//  Created by Marko Radulovic (RIT Student) on 27.11.2023..
//

import SwiftUI





struct DashBoardView: View {

    
    var body: some View {
        List{

        }.navigationTitle("Settings")
    }
}

#Preview {
    NavigationStack{
       // DashBoardView(showSignedIn: .constant(false))
    }
}
