//
//  DashboardView.swift
//  Tradescape
//
//  Created by Marko Radulovic (RIT Student) on 29.11.2023..
//

import SwiftUI

struct DashboardView: View {
    @Binding  var balance:Double
    @State private var numberString: String = ""
    @State private var numberString1: String = ""
    
    @State private var isShown:Bool = false
    @State private var showAlert:Bool=false
    @State private var items:[TransactionItem]=[]
    @State private var portfolioItems:[PortoflioItem]=[]
    
    
    var formattedBalance: String {
        return String(format: "$%.2f", balance)
    }
    
    var body: some View {
        VStack{
            HStack{
                Text("Welcome!")
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundColor(.primary)
                Spacer()
                Button {
                    if let url = URL(string: "https://www.youtube.com/watch?v=lNdOtlpmH5U"){
                        UIApplication.shared.open(url, options: [:], completionHandler: nil)
                    }
                } label: {
                    Image(systemName: "info.circle")
                        .resizable()
                        .frame(width: 30, height: 30)
                        .foregroundColor(.primary)
                        
                }

                
            }.padding()
            VStack{
                HStack {
                    Text("Portfolio Balance:")
                        .font(.title2)
                        .fontWeight(.regular)
                        .foregroundColor(.white)
                    Spacer()
                    Button(action: {
                        isShown=true
                    }, label: {
                        Text("Edit")
                            .foregroundColor(.white)
                            .fontWeight(.heavy)
                    })
                }.padding(.top,20)
                    .padding(.horizontal)
                HStack {
                    Text(formattedBalance)
                        .fontWeight(.heavy)
                        .font(.system(size: 40))
                        .foregroundColor(.white)
                    Spacer()
                }.padding()
                
            }.background(Color("mainAppColor"))
                .cornerRadius(20)
                .padding(.horizontal)
            HStack {
                Text("Portfolio")
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundColor(.primary)
                Spacer()
                
            }.padding()
            DashBoardPortfolioItems(balance:$balance,items:portfolioItems)
            HStack {
                Text("Recent Transactions")
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundColor(.primary)
                Spacer()
                
            }.padding()
            
            TransactionItems(items: items)
            Spacer()
            
        }.background(Color("backgroundColor"))
            .sheet(isPresented: $isShown, content: {
                VStack{
                    HStack {
                        Text("Add Balance:")
                            .font(.title)
                            .fontWeight(.bold)
                            .foregroundColor(Color("mainAppColor"))
                        Spacer()
                    }.padding()
                    HStack {
                        Text("To increase your balance, you can use our secure payment method to add funds, and the deposited money is reflected in your account balance, denominated in USD.")
                            .font(.headline)
                            .fontWeight(.bold)
                            .foregroundColor(.primary)
                        Spacer()
                    }.padding()
                    HStack{
                        Text("$")
                        TextField("", text: $numberString,prompt: Text("9.99"))
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                        
                    }
                    .padding()
                    .cornerRadius(15)
                    HStack {
                        Button(action: {
                            isShown = false
                        }, label: {
                            Text("Cancel")
                                .font(.headline)
                                .foregroundColor(.red)
                                .frame(maxWidth:200)
                                .frame(height: 55)
                                .background(Color.gray.opacity(0.1))
                                .cornerRadius(10)
                        })
                        
                        
                        Button(action: {
                            if numberString.isEmpty{
                                showAlert=true
                                return
                            }
                            if Double(numberString) == nil {
                                showAlert=true
                                return
                            }
                            if Double(numberString)! < 1 {
                                showAlert=true
                                return
                            }
                            balance += Double(numberString)!
                            UserDefaults.standard.set(balance, forKey: "balance")
                            isShown=false
                            numberString = ""
                            
                        }, label: {
                            Text("Add to wallet")
                                .font(.headline)
                                .foregroundColor(.white)
                                .frame(maxWidth:200)
                                .frame(height: 55)
                                .background(Color("mainAppColor"))
                                .cornerRadius(10)
                        }).alert(isPresented: $showAlert) {
                            Alert(
                                title: Text("Transaction failed"),
                                message: Text("Deposit amount can't be left empty"),
                                dismissButton: .default(Text("Try Again"))
                            )
                        }
                        Spacer()
                    }.padding()
                    Spacer()
                }
                VStack{
                    HStack {
                        Text("Withdraw Money:")
                            .font(.title)
                            .fontWeight(.bold)
                            .foregroundColor(Color("mainAppColor"))
                        Spacer()
                    }.padding()
                    HStack {
                        Text("To withdraw from your portfolio, you can use our secure payment method to withdraw funds, and the withdrawn money is reflected in your account balance, denominated in USD.")
                            .font(.headline)
                            .fontWeight(.bold)
                            .foregroundColor(.primary)
                        Spacer()
                    }.padding()
                    HStack{
                        Text("$")
                        TextField("", text: $numberString1,prompt: Text("9.99"))
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                        
                    }
                    .padding()
                    .cornerRadius(15)
                    HStack {
                        Button(action: {
                            isShown = false
                        }, label: {
                            Text("Cancel")
                                .font(.headline)
                                .foregroundColor(.red)
                                .frame(maxWidth:200)
                                .frame(height: 55)
                                .background(Color.gray.opacity(0.1))
                                .cornerRadius(10)
                        })
                        
                        
                        Button(action: {
                            if numberString1.isEmpty{
                                showAlert=true
                                return
                            }
                            if Double(numberString1) == nil {
                                showAlert=true
                                return
                            }
                            if Double(numberString1)! < 1 {
                                showAlert=true
                                return
                            }
                            if Double(numberString1)! > balance{
                                showAlert=true
                                return
                            }
                            balance -= Double(numberString1)!
                            UserDefaults.standard.set(balance, forKey: "balance")
                            isShown=false
                            numberString1 = ""
                            
                        }, label: {
                            Text("Withdraw from wallet")
                                .font(.headline)
                                .foregroundColor(.white)
                                .frame(maxWidth:200)
                                .frame(height: 55)
                                .background(Color("mainAppColor"))
                                .cornerRadius(10)
                        }).alert(isPresented: $showAlert) {
                            Alert(
                                title: Text("Transaction failed"),
                                message: Text("Deposit amount can't be left empty"),
                                dismissButton: .default(Text("Try Again"))
                            )
                        }
                        Spacer()
                    }.padding()
                    Spacer()
                }
            }).background(Color("backgroundColor"))
            .onAppear{
                
                self.balance = UserDefaults.standard.double(forKey: "balance")
                if let encodedData1 = UserDefaults.standard.data(forKey: "transactionItems") {
                    // Decoding the data into an array of CustomObject
                    let decoder = PropertyListDecoder()
                    do {
                        let decodedObjects = try decoder.decode([TransactionItem].self, from: encodedData1)
                        // Use the decoded array
                        self.items = decodedObjects.sorted(by: { $0.creationDate > $1.creationDate })
                    } catch {
                        // Handle decoding error
                        print("Error decoding custom objects: \(error)")
                    }
                } else {
                    return
                }
                if let encodedData1 = UserDefaults.standard.data(forKey: "portfolioItems") {
                    // Decoding the data into an array of CustomObject
                    let decoder = PropertyListDecoder()
                    do {
                        let decodedObjects = try decoder.decode([PortoflioItem].self, from: encodedData1)
                        // Use the decoded array
                        self.portfolioItems = decodedObjects
                    } catch {
                        // Handle decoding error
                        print("Error decoding custom objects: \(error)")
                    }
                } else {
                    return
                }
            }
            .onChange(of:balance){
                self.balance = UserDefaults.standard.double(forKey: "balance")
                if let encodedData1 = UserDefaults.standard.data(forKey: "portfolioItems") {
                    // Decoding the data into an array of CustomObject
                    let decoder = PropertyListDecoder()
                    do {
                        let decodedObjects = try decoder.decode([PortoflioItem].self, from: encodedData1)
                        // Use the decoded array
                        self.portfolioItems = decodedObjects
                    } catch {
                        // Handle decoding error
                        print("Error decoding custom objects: \(error)")
                    }
                } else {
                    return
                }
            }
    
    }
}


