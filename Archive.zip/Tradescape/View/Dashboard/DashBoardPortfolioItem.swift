//
//  DashBoardPortfolioItem.swift
//  Tradescape
//
//  Created by Marko Radulovic (RIT Student) on 29.11.2023..
//

import SwiftUI
import Alamofire
struct PortoflioItemRow: View{
    @State var item:PortoflioItem
    @State var currentStock:Stock
    @State var isShown:Bool = false
    @State var showSheet:Bool = false
    @State var showAlert:Bool = false
    @State private var portfolioItems: [PortoflioItem] = []

    @State var quantity:Int=0
    
    @Binding  var balance:Double


    var percentage: String {
        guard let currentPrice = Double(currentStock.preMarketPrice.replacingOccurrences(of: "$", with: "")),
            item.stockPriceDuring != 0 else {
            return "N/A"
        }
        guard let previousPrice = Double(item.stock.preMarketPrice.replacingOccurrences(of: "$", with: "")),
            Double(item.stock.preMarketPrice) != 0 else {
            return "N/A"
        }
        let percent = ((currentPrice - previousPrice) / previousPrice ) * 100
        return String(format: "%.2f%%", percent)
    }
    var totalAmount :Double{
        return (Double(quantity)*price)
    }
    
    var formattedTotalAmount: String {
        return String(format: "%.2f", totalAmount)
    }
    var price:Double {
        return Double(currentStock.preMarketPrice.replacingOccurrences(of: "$", with: ""))!
    }
    var formattedPrice:String{
        
        return String(format:"%.2f",item.stock.preMarketPrice)
    }
    
  
    
    func loadData(){
        let apiURL = "http://localhost:3000/api/getUpdatedStock/\(item.stock.symbol)"
        AF.request(apiURL).responseDecodable(of: Stock.self) { response in
               switch response.result {
               case .success(let stock):
                   self.currentStock = stock
               case .failure(let error):
                   print("Error fetching data: \(error)")
               }
           }
        if let encodedData1 = UserDefaults.standard.data(forKey: "portfolioItems") {
            // Decoding the data into an array of CustomObject
            let decoder = PropertyListDecoder()
            do {
                let decodedObjects = try decoder.decode([PortoflioItem].self, from: encodedData1)
                // Use the decoded array
                self.portfolioItems = decodedObjects
            } catch {
                // Handle decoding error
                print("Error decoding custom objects: \(error)")
            }
        } else {
          return
        }
        

    }
    
    var body: some View{
        VStack{
            HStack {
                Image(item.stock.symbol.lowercased())
                    .resizable()
                    .scaledToFit()
                    .frame(width: 40, height: 40)

                Text(item.stock.symbol)
                    .fontWeight(.bold)
                    .foregroundColor(.primary)
                
                Spacer()
                Button(action: {
                    isShown=true
                }, label: {
                    Text("View")
                        .foregroundColor(.primary)
                })
                
            }.padding()
            HStack {
                Text("Total Invested: ")
                    .bold()
                Spacer()
                Text("$ \(String(format: "%.2f",item.totalPrice)) ")
                    .fontWeight(.heavy)
                    .font(.system(size: 24))
                    .foregroundColor(.white)
            }.padding()
            
        }.background(Color("mainAppColor"))
            .listRowBackground(Color("backgroundColor"))
            .cornerRadius(20)
            .listRowSeparator(.hidden)
            .fullScreenCover(isPresented: $isShown){
                VStack {
                    HStack{
                        Button(action: {
                            isShown = false
                        }, label: {
                            HStack{
                                Image(systemName: "arrowshape.turn.up.backward.fill")
                                    .foregroundColor(Color("mainAppColor"))
                                Text("Back")
                                    .font(.headline)
                                    .foregroundColor(Color("mainAppColor"))
                                    .frame(maxWidth: 50)
                                    .frame(height: 30)
                                    .cornerRadius(10)
                                Image(item.stock.symbol.lowercased())
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 30,height: 30)
                                    .shadow(color: Color.white.opacity(0.2), radius: 10, x: 0, y: 1)
                                
                                Text(item.stock.name)
                                    .foregroundColor(.primary)
                                
                            }

                        })
                        
                        Spacer()
                    }
                    .background(.clear)
                    .padding(.horizontal)
                    Form{
                        Section(header:Text("Current Prices")){
                            VStack(alignment: .leading) {
                                Text("Primary Exchange: \(item.stock.primaryExchange)")
                                Divider()
                                Text("Increase/Decrease: \(percentage)")
                                Divider()
                                Text("Price at buy: \(item.stock.preMarketPrice)")
                                Divider()
                                Text("Current Price: \(currentStock.preMarketPrice)")
                                Divider()
                                Text("Day Range: \(item.stock.dayRange)")
                                Divider()
                                Text("Year Range: \(item.stock.yearRange)")
                                Divider()
                                Text("Market Cap: \(item.stock.marketCap)")
                                Divider()
                                Text("Average Volume: \(item.stock.avgVolume)")
                                Divider()
                                Text("P/E Ratio: \(item.stock.peRatio)")
                                Divider()
                                Text("Dividend Yield: \(item.stock.dividendYield)")
                                Divider()
                                Text("CDP climate change score: \(item.stock.cdpClimateChangeScore)")
                                Divider()
                                Button {
                                    showSheet = true
                          
                                } label: {
                                    Text("Sell").foregroundColor(Color("mainAppColor"))
                                }

                                
                            }
                        }
                    }
                    .background(Color("backgroundColor"))
                    .scrollContentBackground(.hidden)
                }.background(Color("backgroundColor"))
                    .sheet(isPresented: $showSheet) {
                        VStack{
                            HStack {
                                Text("Sell \(item.stock.name)")
                                    .font(.title)
                                    .fontWeight(.bold)
                                    .foregroundColor(Color("mainAppColor"))
                                Image(item.stock.symbol.lowercased())
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 30, height: 30)
                                    .shadow(color: Color.white.opacity(0.2), radius: 10, x: 0, y: 1)
                                
                                Spacer()
                            }.padding()
                            HStack {
                                Text("Do you want to sell \(item.stock.symbol) \nCurrent price : \(currentStock.preMarketPrice)")
                                    .font(.headline)
                                    .fontWeight(.bold)
                                    .foregroundColor(.primary)
                                Spacer()
                            }.padding()
                            VStack {
                                HStack{
                                    Stepper(value: $quantity, in: 0...item.amount, label: {
                                        Text("Quantity: \(quantity)")
                                            .font(.headline)
                                            .foregroundColor(.primary)
                                    })
                                    .padding()
                                }
                                HStack{
                                    Text("Total Amount: $\(formattedTotalAmount)")
                                        .fontWeight(.bold)
                                    Spacer()
                                }.padding()
                            }
                            HStack {
                                Button(action: {
                                    isShown = false
                                }, label: {
                                    Text("Cancel")
                                        .font(.headline)
                                        .foregroundColor(.red)
                                        .frame(maxWidth:200)
                                        .frame(height: 55)
                                        .background(Color.gray.opacity(0.1))
                                        .cornerRadius(10)
                                })
                                
                                
                                Button(action: {
                                    let encoder = PropertyListEncoder()
                                    for index in 0..<portfolioItems.count{
                                        if portfolioItems[index].stock.symbol == item.stock.symbol{
                                            portfolioItems[index].amount -= quantity
                                            item.amount -= quantity
                                            item.totalPrice -= totalAmount
                                            portfolioItems[index].totalPrice -= totalAmount
                                            if item.amount == 0 {
                                                portfolioItems.remove(at: index)
                                            }
                                         
                                            break
                                        }
                                    }
                                    
                                    isShown = false
                                    balance += totalAmount
                                    if let encodedTransaction = try? encoder.encode(portfolioItems) {
                                        UserDefaults.standard.set(encodedTransaction, forKey: "portfolioItems")
                                    } else {
                                        print("Error encoding transaction objects")
                                    }
                                    
                                    UserDefaults.standard.set(balance, forKey: "balance")
                               
                                    
                                }, label: {
                                    Text("Sell")
                                        .font(.headline)
                                        .foregroundColor(.white)
                                        .frame(maxWidth:200)
                                        .frame(height: 55)
                                        .background(Color("mainAppColor"))
                                        .cornerRadius(10)
                                }).alert(isPresented: $showAlert) {
                                    Alert(
                                        title: Text("Transaction failed"),
                                        message: Text("Balance can't be left empty"),
                                        dismissButton: .default(Text("Try Again"))
                                    )
                                }
                                Spacer()
                            }.padding()
                            Spacer()
                        }

                    }
            }.onAppear{
                loadData()
                        
            }
            .onChange(of:currentStock.preMarketPrice){
                loadData()
            }
    }
}

struct DashBoardPortfolioItems: View {
    @Binding  var balance:Double
    var items:[PortoflioItem]
    var body: some View {
        VStack{
            if(items.isEmpty){
                HStack{
                    Text("You have no stock in your portfolio")
                        .font(.title3)
                        .bold()
                        .foregroundColor(.primary)
                    Spacer()
                }.padding()
            }
            else{
                List(items) { item in
                    PortoflioItemRow(item: item,currentStock:item.stock,balance: $balance)
                }
                .listStyle(.plain)
            }
        }
    }
}

