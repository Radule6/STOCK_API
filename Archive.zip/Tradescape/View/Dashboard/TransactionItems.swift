//
//  DashBoardPortfolioItem.swift
//  Tradescape
//
//  Created by Marko Radulovic (RIT Student) on 29.11.2023..
//

import SwiftUI



struct  TransactionItemRow:View {
    @State var isShown:Bool = false
    var item:TransactionItem
    var body: some View {
        VStack{
            HStack {
                Image(item.stock.symbol.lowercased())
                    .resizable()
                    .scaledToFit()
                    .frame(width: 40, height: 40)
                Text(item.stock.symbol)
                    .fontWeight(.bold)
                Spacer()
                Button(action: {
                    isShown  = true
                }, label: {
                    Text("View")
                })
              
            }.padding()
            HStack {
                Text("Total Price")
                    .bold()
                    .foregroundColor(.primary)
                Spacer()
                Text("$ \(String(item.totalPrice)) ")
                    .fontWeight(.heavy)
                    .font(.system(size: 24))
                    .foregroundColor(.white)
            }.padding()
            
        }.background(Color("mainAppColor"))
            .listRowBackground(Color("backgroundColor"))
            .cornerRadius(20)
            .listRowSeparator(.hidden)
            .fullScreenCover(isPresented: $isShown){
                VStack {
                    HStack{
                        Button(action: {
                            isShown = false
                        }, label: {
                            HStack{
                                Image(systemName: "arrowshape.turn.up.backward.fill")
                                    .foregroundColor(Color("mainAppColor"))
                                Text("Back")
                                    .font(.headline)
                                    .foregroundColor(Color("mainAppColor"))
                                    .frame(maxWidth: 50)
                                    .frame(height: 30)
                                    .cornerRadius(10)
                                Image(item.stock.symbol.lowercased())
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 30,height: 30)
                                    .shadow(color: Color.white.opacity(0.2), radius: 10, x: 0, y: 1)

                                Text(item.stock.name)
                                    .foregroundColor(.primary)

                            }
                            
                        })
                        Spacer()
                    }
                    .background(.clear)
                    .padding(.horizontal)
                    Form{
                        Section(header:Text("Current Prices")){
                            VStack(alignment: .leading) {
                                Text("Primary Exchange: \(item.stock.primaryExchange)")
                                Divider()
                                Text("Previous Close Price: \(item.stock.previousClosePrice)")
                                Divider()
                                Text("Current Price: \(item.stock.preMarketPrice)")
                                Divider()
                                Text("Day Range: \(item.stock.dayRange)")
                                Divider()
                                Text("Year Range: \(item.stock.yearRange)")
                                Divider()
                                Text("Market Cap: \(item.stock.marketCap)")
                                Divider()
                                Text("Average Volume: \(item.stock.avgVolume)")
                                Divider()
                                Text("P/E Ratio: \(item.stock.peRatio)")
                                Divider()
                                Text("Dividend Yield: \(item.stock.dividendYield)")
                                Divider()
                                Text("CDP climate change score: \(item.stock.cdpClimateChangeScore)")
                                Divider()
                            }
                        }
                        
                        Section(header:Text("About the company")){
                            VStack(alignment: .leading) {
                                Text("Name: \(item.stock.name)")
                                Divider()
                                Text("Symbol: \(item.stock.symbol)")
                                Divider()
                                Text("Founded: \(item.stock.founded)")
                                Divider()
                                Text("Headquarters: \(item.stock.headquarters)")
                                Divider()
                                Text("CEO: \(item.stock.ceo)")
                                Divider()
                                Text("Website: \(item.stock.website)")
                                Divider()
                                Text("About:")
                                Text(item.stock.about)
                            }
                        }
                        
                    }
                    .background(Color("backgroundColor"))
                    .scrollContentBackground(.hidden)
                }.background(Color("backgroundColor"))
            }
    }
}



struct TransactionItems: View {
  var items:[TransactionItem]

    var body: some View {
        VStack{
            if(items.isEmpty){
                HStack{
                    Text("You have no transactions")
                        .font(.title3)
                        .bold()
                        .foregroundColor(.primary)
                    Spacer()
                }.padding()
            }
            else{
                List(items) { item in
                    TransactionItemRow(item:item)
                    
                }
                .listStyle(.plain)
            }
        }
    }
}
