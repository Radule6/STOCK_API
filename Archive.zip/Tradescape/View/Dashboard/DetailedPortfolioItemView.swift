//
//  DetailedPortfolioItemView.swift
//  Tradescape
//
//  Created by Marko Radulovic (RIT Student) on 04.12.2023..
//

import SwiftUI

struct DetailedPortfolioItemView: View {
    @State var isShown:Bool = false
    @State var showAlert:Bool = false
    
    var item:PortoflioItem
    var body: some View {
        VStack {
            Form{
                Section(header:Text("Current Prices")){
                    VStack(alignment: .leading) {
                        Text("Primary Exchange: \(item.stock.primaryExchange)")
                        Divider()
                        Text("Previous Close Price: \(item.stock.previousClosePrice)")
                        Divider()
                        Text("Current Price: \(item.stock.preMarketPrice)")
                        Divider()
                        Text("Day Range: \(item.stock.dayRange)")
                        Divider()
                        Text("Year Range: \(item.stock.yearRange)")
                        Divider()
                        Text("Market Cap: \(item.stock.marketCap)")
                        Divider()
                        Text("Average Volume: \(item.stock.avgVolume)")
                        Divider()
                        Text("P/E Ratio: \(item.stock.peRatio)")
                        Divider()
                        Text("Dividend Yield: \(item.stock.dividendYield)")
                        Divider()
                        Text("CDP climate change score: \(item.stock.cdpClimateChangeScore)")
                        Divider()
                        Button(action: {
                            
                            //                            if balance < price{
                            //                                showAlert = true
                            //                                return
                            //                            }
                            //                            isShown = true
                        }, label: {
                            Text("Buy")
                                .font(.headline)
                                .foregroundColor(.white)
                                .frame(maxWidth: 100)
                                .frame(height: 40)
                                .background(Color("mainAppColor"))
                                .cornerRadius(10)
                        })
                    }
                }
                
                Section(header:Text("About the company")){
                    VStack(alignment: .leading) {
                        Text("Name: \(item.stock.name)")
                        Divider()
                        Text("Symbol: \(item.stock.symbol)")
                        Divider()
                        Text("Founded: \(item.stock.founded)")
                        Divider()
                        Text("Headquarters: \(item.stock.headquarters)")
                        Divider()
                        Text("CEO: \(item.stock.ceo)")
                        Divider()
                        Text("Website: \(item.stock.website)")
                        Divider()
                        Text("About:")
                        Text(item.stock.about)
                    }
                }
                
            }
            .background(Color("backgroundColor"))
            .scrollContentBackground(.hidden)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar{
                ToolbarItem(placement:.principal){
                    HStack{
                        Image(item.stock.symbol.lowercased())
                            .resizable()
                            .scaledToFit()
                            .frame(width: 30, height: 30)
                            .shadow(color: Color.white.opacity(0.2), radius: 10, x: 0, y: 1)
                        Text(item.stock.name)
                    }
                }
            }
        }.background(Color("backgroundColor"))
            .sheet(isPresented: $isShown){
                VStack{
                    HStack {
                        Text("Buy \(item.stock.name)")
                            .font(.title)
                            .fontWeight(.bold)
                            .foregroundColor(Color("mainAppColor"))
                        Image(item.stock.symbol.lowercased())
                            .resizable()
                            .scaledToFit()
                            .frame(width: 30, height: 30)
                            .shadow(color: Color.white.opacity(0.2), radius: 10, x: 0, y: 1)
                        
                        Spacer()
                    }.padding()
                    HStack {
                        Text("Do you want to buy \(item.stock.symbol) \nCurrent price : \(item.stock.preMarketPrice)")
                            .font(.headline)
                            .fontWeight(.bold)
                            .foregroundColor(.primary)
                        Spacer()
                    }.padding()
                    VStack {
                        //                        HStack{
                        //                            Text("Current Balance: \(formattedBalance)")
                        //                                .fontWeight(.bold)
                        //                            Spacer()
                        //                        }.padding()
                        HStack{
                            
                            //                            Stepper(value: $quantity, in: 0...totalQuantity, label: {
                            //                                Text("Quantity: \(quantity)")
                            //                                    .font(.headline)
                            //                                    .foregroundColor(.primary)
                            //                            }).padding()
                        }
                        HStack{
                            //                            Text("Total Amount: $\(formattedTotalAmount)")
                            //                                .fontWeight(.bold)
                            //                            Spacer()
                            //                        }.padding()
                        }
                        HStack {
                            Button(action: {
                                isShown = false
                            }, label: {
                                Text("Cancel")
                                    .font(.headline)
                                    .foregroundColor(.red)
                                    .frame(maxWidth:200)
                                    .frame(height: 55)
                                    .background(Color.gray.opacity(0.1))
                                    .cornerRadius(10)
                            })
                            
                            
                            Button(action: {
                                
                                
                            }, label: {
                                Text("Add to Portfolio")
                                    .font(.headline)
                                    .foregroundColor(.white)
                                    .frame(maxWidth:200)
                                    .frame(height: 55)
                                    .background(Color("mainAppColor"))
                                    .cornerRadius(10)
                            }).alert(isPresented: $showAlert) {
                                Alert(
                                    title: Text("Transaction failed"),
                                    message: Text("Balance can't be left empty"),
                                    dismissButton: .default(Text("Try Again"))
                                )
                            }
                            Spacer()
                        }.padding()
                        Spacer()
                    }        }
                .alert(isPresented: $showAlert){
                    Alert(title: Text("Insufficient Funds"),
                          message:Text("You need to deposit money to your wallet"),
                          dismissButton: .default(Text("Try Again"))
                    )
                }
            }
    }
}

//#Preview {
//    DetailedPortfolioItemView()
//}
